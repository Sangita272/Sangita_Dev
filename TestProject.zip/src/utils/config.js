const bash_url = 'http://api.vintagebazaar.in/';
export default bash_url;