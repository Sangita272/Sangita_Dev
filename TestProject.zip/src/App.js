import logo from './logo.svg';
import './App.css';
import Index from './Pages';
import Crud from './Pages/Crud';
// import Index from './Pages';


function App() {
  return (
    <div className="App">
{/* <Index/> */}
<Crud/>
    </div>
  );
}

export default App;
